/**
 *
 * @author mounika,hari
 */
package com.adaptive.entities;

import java.util.HashMap;
import java.util.Map;


public class TestType {
	
	public static Map<String, String> map  = new HashMap<String, String>();; 
	static{
	 map.put("1", "MATHS");
         map.put("2", "SPELLING");  
         map.put("3", "WRITING");  
         map.put("4", "LISTENING");  
	}
	
	
}