

Project Description:
This is an Adaptive test application, that allows stdents to take exam. Student has to provide their name, 
student ID and school name, which gives them with a temporary PIN. Once the student has logged in with His
ID and temporary PIN, he will be directed to the category page where he has to select of of the question category.
There are two timers displayed in the all the question categories. One displaying the overall time available for 
all the categories and the second one displaying the time left for the specific setion. When the time left for the 
section is below one minuite, timer turns into red color, followed by an alert sound. 
Test ends after the completion of all the categories Test details of students is 
stored in the database.
 

The following features were completed in the project.
1. Automatic random pin generation
2. Logging in with the pin generated 
2. Option of selecting question categories
3. Two timers displaying time left for current section and overall time of the test
4. Timer turning to red when time left is one minuite
5. Alert sound a when the time left is 1min(The sound is not recorded in the video 
as the recording software failed to do so, but it is working in code)
6. Disabiling. yet displaying other categories while answering one of the test categories
7. Option to submit test at any question
8. Highlighting the mistakes in sentences in red color
9. Playing audio recordings for questions in listining section
10.Test will be submitted automatically, even if the student fails to submit it before the time.


